﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFAcalculator
{
    public partial class Form1 : Form
    {
        string input = string.Empty;         
        string opn1 = string.Empty;         
        string opn2 = string.Empty;        
        char operation;                   
        double result = 0.0;             



        public Form1()
        {
            InitializeComponent();
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";   
            input += "0";
            this.txtCalculator.Text += input;   
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "1";
            this.txtCalculator.Text += input;
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "2";
            this.txtCalculator.Text += input;
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "3";
            this.txtCalculator.Text += input;
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "4";
            this.txtCalculator.Text += input;
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "5";
            this.txtCalculator.Text += input;
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "6";
            this.txtCalculator.Text += input;
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "7";
            this.txtCalculator.Text += input;
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "8";
            this.txtCalculator.Text += input;
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            input += "9";
            this.txtCalculator.Text += input;
        }
        private void btnPercentage_Click(object sender, EventArgs e)
        {
            
            opn1 = input;
            operation = '%';
            input = string.Empty;
            

        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            
            opn1 = input;
            operation = '+';
            input = string.Empty;
           

        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            
            opn1 = input;
            operation = '-';
            input = string.Empty;
           
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
           
            opn1 = input;
            operation = '*';
            input = string.Empty;
            
        }

        private void btnDivition_Click(object sender, EventArgs e)
        {
           
            opn1 = input;
            operation = '/';
            input = string.Empty;
           
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.txtCalculator.Text = "";
            this.input = string.Empty;
            this.opn1 = string.Empty;
            this.opn2 = string.Empty;
        }

        private void btnEqualTo_Click(object sender, EventArgs e)
        {
            opn2 = input;
            double num1, num2;
            double.TryParse(opn1, out num1);
            double.TryParse(opn2, out num2);

            if (operation == '+')
            {
                result = num1 + num2;
                txtCalculator.Text = result.ToString();
            }
            else if (operation == '-')
            {
                result = num1 - num2;
                txtCalculator.Text = result.ToString();
            }
            else if (operation == '*')
            {
                result = num1 * num2;
                txtCalculator.Text = result.ToString();
            }


            else if (operation == '%')
            {
                result = num1 * 0.01;
                txtCalculator.Text = result.ToString();
            }



            else if (operation == '/')
            {
                if (num2 != 0)
                {
                    result = num1 / num2;
                    txtCalculator.Text = result.ToString();
                }
                else
                {
                    txtCalculator.Text = "Error!";
                }

            }
        }

       
    }
}
